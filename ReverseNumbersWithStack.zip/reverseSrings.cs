﻿using System;
using System.Collections.Generic;

namespace ReverseNumbersWithStack
{
    class reverseSrings
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine();//пишем си входа.
            var stack = new Stack<char>();// създаваме стек от char

            foreach (var items in input)//след това обхождаме всички char в подадения ни вход
            {
                stack.Push(items);//със командата Push слагаме всички char в стека.
            }

            while (stack.Count > 0)//с  while цикъла обхождаме стека докато има елементи в него
            {
                Console.Write(stack.Pop());//с командата Pop изваждаме всички char от стека и те излизат в обратен ред.
            }

            Console.WriteLine();
        }
    }
}
