﻿ using System;
using System.Collections.Generic;

namespace TrafficLight
{
    class Program
    {
        static void Main(string[] args)
        {
            int cars = int.Parse(Console.ReadLine());
            string inputLine = Console.ReadLine();
            int count = 0;
            var queue = new Queue<string>();
            while (inputLine != "end")
            {
                if (inputLine == "green")
                {
                    var carsCanPass = Math.Min(queue.Count, cars);
                    for (int i = 0; i < carsCanPass; i++)
                    {
                        Console.WriteLine($"{queue.Dequeue()} passed!");
                        count++;
                    }
                }
                else
                {
                    queue.Enqueue(inputLine);
                }

                inputLine = Console.ReadLine();
            }

            Console.WriteLine($"{count} cars passed the crossroads.");
        }
    }
}
