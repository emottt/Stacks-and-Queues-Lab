﻿using System;
using System.Collections.Generic;

namespace SimpleCalculator
{
    class simpleCalculator
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine();
            var elements = input.Split(' ');
            var stack = new Stack<string>();

            for (int counter =elements.Length-1; counter >= 0; counter--)
            {
                stack.Push(elements[counter]);//така пълним стека
            }

            while (stack.Count > 1)//след като сме напълнили стека тои има 9 елемента и изпълняваме команди доката не станат елементите по малко от 1
            
            {
                var leftOperand = int.Parse(stack.Pop());
                var operation = stack.Pop();
                var rightOperand = int.Parse(stack.Pop());
                // след това делим входа на 3 части лява и дясна в който са числата и средната в която са операторите като плюс и минус
                switch (operation)
                {
                    case "+":
                        stack.Push((leftOperand + rightOperand).ToString());
                        break;
                    case "-":
                        stack.Push((leftOperand - rightOperand).ToString());
                        break;
                    // правим един switch case и в него изпълняваме операцията събиране или изваждане 

                }
            }

            Console.WriteLine(stack.Pop());
        }
    }
}
