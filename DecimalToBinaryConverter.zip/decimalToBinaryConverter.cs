﻿using System;
using System.Collections.Generic;

namespace DecimalToBinaryConverter
{
    class decimalToBinaryConverter
    {
        static void Main(string[] args)
        {
            var inputLine = int.Parse(Console.ReadLine());
            var stack = new Stack<int>();

            if (inputLine == 0)
            {
                Console.WriteLine(0);
                return;
            }
            while (inputLine > 0)
            {
                stack.Push(inputLine % 2);
                inputLine /= 2;
            }

            while (stack.Count > 0)
            {
                Console.Write(stack.Pop());
            }

            Console.WriteLine();
        }
    }
}
