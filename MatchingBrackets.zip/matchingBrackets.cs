﻿using System;
using System.Collections.Generic;

namespace MatchingBrackets
{
    class matchingBrackets
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            var stack = new Stack<int>();
            for (int counter = 0; counter < input.Length; counter++)
            {
                if (input[counter] =='(')
                {
                    stack.Push(counter);
                }

                if (input[counter] == ')')
                {
                    var brackets = stack.Pop();
                    var length = counter - brackets + 1;
                    Console.WriteLine(input.Substring(brackets, length));
                }
            }
        }
    }
}
